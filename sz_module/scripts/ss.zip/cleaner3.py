from qgis.PyQt.QtCore import QCoreApplication,QVariant
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterRasterLayer,
                       QgsMessageLog,
                       Qgis,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterFileDestination,
                       QgsProcessingParameterVectorLayer,
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsProject,
                       QgsField,
                       QgsFields,
                       QgsVectorFileWriter,
                       QgsWkbTypes,
                       QgsFeature,
                       QgsGeometry,
                       QgsPointXY
                       )
from qgis import processing
import gdal,ogr,osr
import numpy as np
import math
import operator
import random
from qgis import *
from scipy import ndimage

class ExampleProcessingAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return ExampleProcessingAlgorithm()

    def name(self):
        return 'cleanerLSD'

    def displayName(self):
        return self.tr('01 cleaner LSD')

    def group(self):
        return self.tr('LSI')

    def groupId(self):
        return 'LSI'

    def shortHelpString(self):
        return self.tr("Clean landslide layer by squared kernel (slope)")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('Slope', self.tr('Slope'), defaultValue='/home/irpi/SinoItalian_Lab/Tier1_SouthAsia/Data/Slope_SE_250m_3857Travis.tif'))
        self.addParameter(QgsProcessingParameterVectorLayer('Inventory', self.tr('Landslides'), types=[QgsProcessing.TypeVectorPoint], defaultValue='/home/irpi/SinoItalian_Lab/Tier1_SouthAsia/Data/nasa_1km3857.shp'))
        self.addParameter(QgsProcessingParameterVectorLayer('poly', self.tr('Polygon'), types=[QgsProcessing.TypeVectorPolygon], defaultValue='/home/irpi/SinoItalian_Lab/Tier1_SouthAsia/Data/polySE3857clean.shp'))
        self.addParameter(QgsProcessingParameterNumber('BufferRadiousInPxl', 'Buffer radious', type=QgsProcessingParameterNumber.Integer, defaultValue = 6,  minValue=1))
        self.addParameter(QgsProcessingParameterNumber('minSlopeAcceptable', 'Min slope acceptable', type=QgsProcessingParameterNumber.Integer, defaultValue = 3,  minValue=1))

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(1, model_feedback)
        results = {}
        outputs = {}
        parameters['Out']='/tmp/nasa_1km3857clean_r6s3SE250mcomplete.shp'
        parameters['Slope'] = self.parameterAsRasterLayer(parameters, 'Slope', context).source()
        parameters['Inventory'] = self.parameterAsVectorLayer(parameters, 'Inventory', context).source()
        parameters['poly'] = self.parameterAsVectorLayer(parameters, 'poly', context).source()

        print('importing')
        alg_params = {
            'INPUT': parameters['poly'],
            'INPUT2': parameters['Slope'],
            'INPUT3' : parameters['Inventory']
        }
        raster,ds1,XY=self.importing(alg_params)
        outputs['raster'] = raster
        outputs['ds1'] = ds1
        outputs['XY'] = XY

        print('indexing')
        alg_params = {
            'INPUT': parameters['BufferRadiousInPxl'],
            'INPUT2': parameters['minSlopeAcceptable'],
            'INPUT3': outputs['raster']
        }
        oout=self.indexing(alg_params)
        outputs['oout'] = oout

        print('vector')
        alg_params = {
            'INPUT': outputs['oout'],
            'INPUT2': outputs['XY'],
            'INPUT3': outputs['ds1']
        }
        XYcoord=self.vector(alg_params)
        outputs['XYcoord'] = XYcoord

        print('save')
        alg_params = {
            'OUTPUT': parameters['Out'],
            'INPUT2': outputs['XYcoord'],
            'INPUT': outputs['ds1']
        }
        self.saveV(alg_params)

        vlayer = QgsVectorLayer(parameters['Out'], 'vector', "ogr")
        QgsProject.instance().addMapLayer(vlayer)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}
        return results

    def importing(self,parameters):
        vlayer = QgsVectorLayer(parameters['INPUT'], "layer", "ogr")
        ext=vlayer.extent()#xmin
        xmin = ext.xMinimum()
        xmax = ext.xMaximum()
        ymin = ext.yMinimum()
        ymax = ext.yMaximum()

        raster={}
        ds1=gdal.Open(parameters['INPUT2'])
        # xc = ds.RasterXSize
        # yc = ds.RasterYSize
        # geot=ds.GetGeoTransform()
        # newXNumPxl=np.round(abs(xmax-xmin)/(abs(geot[1]))).astype(int)
        # newYNumPxl=np.round(abs(ymax-ymin)/(abs(geot[5]))).astype(int)
        # try:
        #     os.system('gdal_translate -of GTiff -ot Float32 -strict -outsize ' + str(newXNumPxl) +' '+ str(newYNumPxl) +' -projwin ' +str(xmin)+' '+str(ymax)+' '+ str(xmax) + ' ' + str(ymin) +' -co COMPRESS=DEFLATE -co PREDICTOR=1 -co ZLEVEL=6 ' + Slope +' '+ '/tmp/sizedslopexxx.tif')
        # except:
        #     raise ValueError  # Failure to save sized cause, see 'WoE' Log Messages Panel
        # del ds
        #ds1=gdal.Open('/tmp/sizedslopexxx.tif')
        #print('a')
        if ds1 is None:
            print("ERROR: can't open raster input")
            raise ValueError  # Failure to save sized cause, see 'WoE' Log Messages Panel
        nodata=ds1.GetRasterBand(1).GetNoDataValue()
        band1=ds1.GetRasterBand(1)
        #print('a00')
        raster[0] = band1.ReadAsArray()
        #print('a0')
        raster[0][raster[0]==nodata]=-9999
        x = ds1.RasterXSize
        y = ds1.RasterYSize
        driverd = ogr.GetDriverByName('ESRI Shapefile')
        #print('a1')
        ds9 = driverd.Open(parameters['INPUT3'],0)
        #print('b')
        layer = ds9.GetLayer()
        print('a')
        for feature in layer:
            geom = feature.GetGeometryRef()
            xy=np.array([geom.GetX(),geom.GetY()])
            try:
                XY=np.vstack((XY,xy))
            except:
                XY=xy
        gtdem= ds1.GetGeoTransform()
        print('c')
        size=np.array([abs(gtdem[1]),abs(gtdem[5])])
        OS=np.array([gtdem[0],gtdem[3]])
        NumPxl=(np.ceil((abs(XY-OS)/size)-1))#from 0 first cell
        NumPxl[NumPxl==-1.]=0
        values=np.zeros((y,x), dtype='Int16')
        for i in range(len(NumPxl)):
            if XY[i,1]<ymax and XY[i,1]>ymin and XY[i,0]<xmax and XY[i,0]>xmin:
                values[NumPxl[i,1].astype(int),NumPxl[i,0].astype(int)]=1
        raster[1]=values[:]
        del values
        del layer
        del ds9
        return raster,ds1,XY

    def indexing(self,parameters):
        ggg=np.array([])
        ggg=parameters['INPUT3'][0][:]#.astype('float32')
        #R=np.array([])
        #R=parameters['INPUT3'][1][:]#.astype('Int16')
        #R[(R==0)]=-9999
        numbb=parameters['INPUT']*2+1
        g = ndimage.generic_filter(ggg, np.nanmax, size=(numbb,numbb))
        oout=np.array([])
        #oout=R*g
        oout=g
        oout[(parameters['INPUT3'][0]==-9999)]=-9999
        oout[(parameters['INPUT3'][1]==0)]=-9999
        del parameters['INPUT3']

        oout[(oout<parameters['INPUT2'])]=-9999
        oout[oout>=parameters['INPUT2']]=1
        #del g
        del ggg
        #del R
        return oout

    def vector(self,parameters):
        row,col=np.where(parameters['INPUT']==1)
        del parameters['INPUT']
        geo=parameters['INPUT3'].GetGeoTransform()
        xsize=geo[1]
        ysize=geo[5]
        OOx=geo[0]
        OOy=geo[3]
        XYcoord=np.array([0,0])
        for i in range(len(col)):
            xmin=OOx+(xsize*col[i])
            xmax=OOx+(xsize*col[i])+(xsize)
            ymax=OOy+(ysize*row[i])
            ymin=OOy+(ysize*row[i])+(ysize)
            for ii in range(len(parameters['INPUT2'])):
                if (parameters['INPUT2'][ii,0]>=xmin and parameters['INPUT2'][ii,0]<=xmax and parameters['INPUT2'][ii,1]>=ymin and parameters['INPUT2'][ii,1]<=ymax):
                    XYcoord=np.vstack((XYcoord,parameters['INPUT2'][ii,:]))
        del parameters['INPUT2']
        #print(XYcoord)
        XYcoord=XYcoord[1:,:]
        return XYcoord

    def saveV(self,parameters):
        # set up the shapefile driver
        driver = ogr.GetDriverByName("ESRI Shapefile")
        # Remove output shapefile if it already exists
        if os.path.exists(parameters['OUTPUT']):
            driver.DeleteDataSource(parameters['OUTPUT'])
        ds=driver.CreateDataSource(parameters['OUTPUT'])
        srs=osr.SpatialReference(wkt = parameters['INPUT'].GetProjection())
        del parameters['INPUT']
        # create the layer
        layer = ds.CreateLayer("inventory_cleaned", srs, ogr.wkbPoint)
        # Add the fields we're interested in
        field_name = ogr.FieldDefn("id", ogr.OFTInteger)
        field_name.SetWidth(5)
        layer.CreateField(field_name)
        # Process the text file and add the attributes and features to the shapefile
        for i in range(len(parameters['INPUT2'])):
            # create the feature
            feature = ogr.Feature(layer.GetLayerDefn())
            # Set the attributes using the values from the delimited text file
            feature.SetField("id", i)
            # create the WKT for the feature using Python string formatting
            wkt = "POINT(%f %f)" % (float(parameters['INPUT2'][i,0]) , float(parameters['INPUT2'][i,1]))
            # Create the point from the Well Known Txt
            point = ogr.CreateGeometryFromWkt(wkt)
            # Set the feature geometry using the point
            feature.SetGeometry(point)
            # Create the feature in the layer (shapefile)
            layer.CreateFeature(feature)
            # Dereference the feature
            feature = None
        # Save and close the data source
        del ds
