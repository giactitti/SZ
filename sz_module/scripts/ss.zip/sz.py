#!/usr/bin/python
#coding=utf-8
"""
/***************************************************************************
    CleanPointsByRasterKernelValue
        begin                : 2020-03
        copyright            : (C) 2020 by Giacomo Titti,
                               Padova, March 2020
        email                : giacomotitti@gmail.com
 ***************************************************************************/

/***************************************************************************
    CleanPointsByRasterKernelValue
    Copyright (C) 2020 by Giacomo Titti, Padova, March 2020

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 ***************************************************************************/
"""
import sys
sys.setrecursionlimit(10000)
from qgis.PyQt.QtCore import QCoreApplication,QVariant
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterRasterLayer,
                       QgsMessageLog,
                       Qgis,
                       QgsProcessingMultiStepFeedback,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterFileDestination,
                       QgsProcessingParameterVectorLayer,
                       QgsVectorLayer,
                       QgsRasterLayer,
                       QgsProject,
                       QgsField,
                       QgsFields,
                       QgsVectorFileWriter,
                       QgsWkbTypes,
                       QgsFeature,
                       QgsGeometry,
                       QgsPointXY,
                       QgsProcessingParameterField,
                       QgsProcessingParameterString,
                       QgsProcessingParameterFolderDestination,
                       QgsProcessingParameterField,
                       QgsProcessingParameterVectorDestination
                       )
from qgis import processing
import gdal,ogr,osr
import numpy as np
import math
import operator
import random
from qgis import *
# ##############################
import matplotlib.pyplot as plt
import csv
from processing.algs.gdal.GdalUtils import GdalUtils
#import plotly.express as px
import chart_studio
import plotly.offline
import plotly.graph_objs as go
#import geopandas as gd
import pandas as pd
# pd.set_option('display.max_columns', 20)
# #pd.set_option('display.max_rows', 20)
# from IPython.display import display


class ProcessingAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'covariates'
    STRING = 'field1'
    STRING1 = 'field2'
    STRING2 = 'fieldlsd'
    #INPUT1 = 'Slope'
    #EXTENT = 'Extension'
    #NUMBER = 'BufferRadiousInPxl'
    #NUMBER1 = 'minSlopeAcceptable'
    OUTPUT = 'OUTPUT'
    OUTPUT2 = 'OUTPUT2'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return ProcessingAlgorithm()

    def name(self):
        return 'WoE'

    def displayName(self):
        return self.tr('02 WoE')

    def group(self):
        return self.tr('SI')

    def groupId(self):
        return 'SI'

    def shortHelpString(self):
        return self.tr("WoE")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT, self.tr('covariates'), types=[QgsProcessing.TypeVectorPolygon], defaultValue='covariatesclassed'))

        #self.addParameter( QgsProcessingParameterFeatureSource(self.INPUT,self.tr('Covariates'),[QgsProcessing.TypeVectorPolygon],defaultValue='covariatesclassed'))




        self.addParameter(QgsProcessingParameterField(self.STRING, 'First field', parentLayerParameterName=self.INPUT, defaultValue='S'))
        self.addParameter(QgsProcessingParameterField(self.STRING1, 'Last field', parentLayerParameterName=self.INPUT, defaultValue='rlf'))
        self.addParameter(QgsProcessingParameterField(self.STRING2, 'lsd field', parentLayerParameterName=self.INPUT, defaultValue='LSD'))



        #self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, 'Output layer', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

        #self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, self.tr('Output layer'), type=QgsProcessing.TypeVectorPolygon, createByDefault=True, defaultValue=None))

        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT, 'Output layer',fileFilter='GeoPackage (*.gpkg *.GPKG)', defaultValue=None))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT2, 'Weights','*.txt', defaultValue=None))

    def processAlgorithm(self, parameters, context, feedback):

        feedback = QgsProcessingMultiStepFeedback(1, feedback)
        results = {}
        outputs = {}

        source = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        parameters['covariates']=source.source()
        if parameters['covariates'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))



        # source = self.parameterAsVectorLayer(
        #     parameters,
        #     self.INPUT,
        #     context
        # )
        # parameters['covariates']=source.source()

        # If source was not found, throw an exception to indicate that the algorithm
        # encountered a fatal error. The exception text can be any string, but in this
        # case we use the pre-built invalidSourceError method to return a standard
        # helper text for when a source cannot be evaluated
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))





        parameters['field1'] = self.parameterAsString(parameters, self.STRING, context)
        if parameters['field1'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.STRING))

        parameters['field2'] = self.parameterAsString(parameters, self.STRING1, context)
        if parameters['field2'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.STRING1))

        parameters['fieldlsd'] = self.parameterAsString(parameters, self.STRING2, context)
        if parameters['fieldlsd'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.STRING2))

        # parameters['poly'] = self.parameterAsExtent(parameters, self.EXTENT, context)
        # if parameters['poly'] is None:
        #     raise QgsProcessingException(self.invalidSourceError(parameters, self.EXTENT))
        #
        # parameters['BufferRadiousInPxl'] = self.parameterAsInt(parameters, self.NUMBER, context)
        # if parameters['BufferRadiousInPxl'] is None:
        #     raise QgsProcessingException(self.invalidSourceError(parameters, self.NUMBER))
        #
        # parameters['minSlopeAcceptable'] = self.parameterAsInt(parameters, self.NUMBER1, context)
        # if parameters['minSlopeAcceptable'] is None:
        #     raise QgsProcessingException(self.invalidSourceError(parameters, self.NUMBER1))


        # (parameters['out'], dest_id) = self.parameterAsSink(
        #     parameters,
        #     self.OUTPUT,
        #     context,
        #     source.fields(),
        #     source.wkbType(),
        #     source.sourceCrs()
        # )
        #
        # # Send some information to the user
        # feedback.pushInfo('CRS is {}'.format(source.sourceCrs().authid()))
        #
        # # If sink was not created, throw an exception to indicate that the algorithm
        # # encountered a fatal error. The exception text can be any string, but in this
        # # case we use the pre-built invalidSinkError method to return a standard
        # # helper text for when a sink cannot be evaluated
        # if parameters['out'] is None:
        #     raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        #(parameters['out'],id,a)=self.parameterAsSink(parameters,self.OUTPUT,context,source.fields(),source.wkbType(),source.sourceCrs())

        # outFile = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        # parameters['out'], outputFormat = GdalUtils.ogrConnectionStringAndFormat(outFile, context)
        # if parameters['out'] is None:
        #     raise QgsProcessingException(self.invalidSourceError(parameters, self.OUTPUT))

        parameters['out'] = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        if parameters['out'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.OUTPUT))

        parameters['out1'] = self.parameterAsFileOutput(parameters, self.OUTPUT2, context)
        if parameters['out1'] is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.OUTPUT2))

        #print(a)
        # Intersectionpoly
        alg_params = {
            #'INPUT_RASTER_LAYER': parameters['Slope'],
            #'INPUT_EXTENT': parameters['Extension'],
            'INPUT_VECTOR_LAYER': parameters['covariates'],
            'field1': parameters['field1'],
            'field2': parameters['field2'],
            'lsd' : parameters['fieldlsd']
            #'INPUT_INT': parameters['BufferRadiousInPxl'],
            #'INPUT_INT_1': parameters['minSlopeAcceptable'],
        }
        outputs['gdp'],outputs['nomes'],outputs['crs']=self.load(alg_params)

        alg_params = {
            'df': outputs['gdp'],
            'nomi':outputs['nomes'],
            'txt':parameters['out1']

        }
        outputs['df']=self.woe(alg_params)

        alg_params = {
            'df': outputs['df'],
            'crs': outputs['crs'],
            'OUT': parameters['out']
        }
        self.save(alg_params)


        #self.importingandcounting(alg_params)
        #self.indexing(alg_params)
        #self.vector()
        #del self.oout
        #outputs['cleaninventory']=self.saveV(alg_params)
        results['out'] = outputs['df']
        #del self.raster

        fileName = parameters['out']
        layer1 = QgsVectorLayer(fileName,"SI","ogr")
        subLayers =layer1.dataProvider().subLayers()

        for subLayer in subLayers:
            name = subLayer.split('!!::!!')[1]
            print(name,'name')
            uri = "%s|layername=%s" % (fileName, name,)
            print(uri,'uri')
            # Create layer
            sub_vlayer = QgsVectorLayer(uri, name, 'ogr')
            if not sub_vlayer.isValid():
                print('layer failed to load')
            # Add layer to map
            context.temporaryLayerStore().addMapLayer(sub_vlayer)
            context.addLayerToLoadOnCompletion(sub_vlayer.id(), QgsProcessingContext.LayerDetails('SI', context.project(),'LAYER1'))

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        return results

    def load(self,parameters):
        layer = QgsVectorLayer(parameters['INPUT_VECTOR_LAYER'], '', 'ogr')
        crs=layer.crs()
        campi=[]
        for field in layer.fields():
            campi.append(field.name())
        campi.append('geom')
        gdp=pd.DataFrame(columns=campi,dtype=float)
        features = layer.getFeatures()
        count=0
        feat=[]
        for feature in features:
            attr=feature.attributes()
            #print(attr)
            geom = feature.geometry()
            #print(type(geom.asWkt()))
            feat=attr+[geom.asWkt()]
            #print(feat)
            gdp.loc[len(gdp)] = feat
            #gdp = gdp.append(feat, ignore_index=True)
            count=+ 1
        gdp.to_csv('/tmp/file.csv')
        del gdp
        gdp=pd.read_csv('/tmp/file.csv')
        #print(feat)
        #print(gdp['S'].dtypes)
        gdp['ID']=np.arange(1,len(gdp.iloc[:,0])+1)
        df=gdp.loc[:,parameters['field1']:parameters['field2']]
        nomi=list(df.head())
        #print(list(df['Sf']),'1')
        lsd=gdp[parameters['lsd']]
        lsd[lsd>0]=1
        df['y']=lsd#.astype(int)
        df['ID']=gdp['ID']
        df['geom']=gdp['geom']
        df=df.dropna(how='any',axis=0)
        #df['ID']=df['ID'].astype('Int32')
        return df,nomi,crs

    def woe(self,parameters):
        df=parameters['df']
        nomi=parameters['nomi']
        Npx1=None
        Npx2=None
        Npx3=None
        Npx4=None
        file = open(parameters['txt'],'w')#################save W+, W- and Wf
        file.write('covariate,class,Npx1,Npx2,Npx3,Npx4,W+,W-,Wf\n')
        for ii in nomi:
            classi=df[ii].unique()
            for i in classi:
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 and x[ii] == i else False, axis = 1)
                Npx1 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 1 and x[ii] != i else False, axis = 1)
                Npx2 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 0 and x[ii] == i else False, axis = 1)
                Npx3 = len(dd[dd == True].index)
                dd=pd.DataFrame()
                dd = df.apply(lambda x : True if x['y'] == 0 and x[ii] != i else False, axis = 1)
                Npx4 = len(dd[dd == True].index)
                if Npx1==0 or Npx3==0:
                    Wplus=0.
                else:
                    Wplus=math.log((Npx1/(Npx1+Npx2))/(Npx3/(Npx3+Npx4)))
                if Npx2==0 or Npx4==0:
                    Wminus=0.
                else:
                    Wminus=math.log((Npx2/(Npx1+Npx2))/(Npx4/(Npx3+Npx4)))
                Wf=Wplus-Wminus
                var=[ii,i,Npx1,Npx2,Npx3,Npx4,Wplus,Wminus,Wf]
                file.write(','.join(str(e) for e in var)+'\n')#################save W+, W- and Wf
                df[ii][df[ii]==i]=float(Wf)
            #df.to_csv('/tmp/file'+ii+'.csv')
        file.close()
        df['SI']=df[nomi].sum(axis=1)
        return(df)

    def save(self,parameters):
        from qgis.PyQt.QtCore import QVariant
        #print(parameters['nomi'])
        df=parameters['df']
        nomi=list(df.head())
        # define fields for feature attributes. A QgsFields object is needed
        fields = QgsFields()

        #fields.append(QgsField('ID', QVariant.Int))

        for field in nomi:
            if field=='ID':
                fields.append(QgsField(field, QVariant.Int))
            if field=='geom':
                continue
            if field=='y':
                fields.append(QgsField(field, QVariant.Int))
            else:
                fields.append(QgsField(field, QVariant.Double))

        #crs = QgsProject.instance().crs()
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = 'GPKG'
        save_options.fileEncoding = 'UTF-8'

        writer = QgsVectorFileWriter.create(
          parameters['OUT'],
          fields,
          QgsWkbTypes.Polygon,
          parameters['crs'],
          transform_context,
          save_options
        )

        if writer.hasError() != QgsVectorFileWriter.NoError:
            print("Error when creating shapefile: ",  writer.errorMessage())
        for i, row in df.iterrows():
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromWkt(row['geom']))
            fet.setAttributes(list(map(float,list(df.loc[ i, df.columns != 'geom']))))
            writer.addFeature(fet)

        # delete the writer to flush features to disk
        del writer
